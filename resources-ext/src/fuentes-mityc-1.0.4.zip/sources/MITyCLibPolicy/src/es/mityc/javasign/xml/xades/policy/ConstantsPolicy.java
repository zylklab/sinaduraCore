/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.xml.xades.policy;

/**
 * <p>Constantes del módulo de Políticas.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public final class ConstantsPolicy {
	/**
	 * Constructor.
	 */
	private ConstantsPolicy() { };
	
	/** Nombre de la librería. */
	public static final String LIB_NAME = "MITyCLibPolicy";

	// No Transforms
	/** Hay transformadas aplicadas al contenido firmado que podrían estar alterando su valor. */
	public static final String I18N_POLICY_NO_TRANSFORMS_1 = "i18n.mityc.policy.notransforms.1";
	/** Política de seguridad restrictiva: Transformadas no permitidas. */
	public static final String I18N_POLICY_NO_TRANSFORMS_2 = "i18n.mityc.policy.notransforms.2";

	// MITyc Trust
	/** No hay disponible un validador de confianza de entidades admitidas por MITyC. */
	public static final String I18N_POLICY_MITYC_TRUST_1 = "i18n.mityc.policy.mityc.1";
	/** Política de confianza MITyC. */
	public static final String I18N_POLICY_MITYC_TRUST_2 = "i18n.mityc.policy.mityc.2";
	/** No hay certificados disponibles para comprobar confianza. */
	public static final String I18N_POLICY_MITYC_TRUST_3 = "i18n.mityc.policy.mityc.3";
	/** El certificado firmante no está recogido en los apartados a) ó c) del artículo 18 del Reglamento que está recogido en R.D. 1496/2003 del 28 de Noviembre.. */
	public static final String I18N_POLICY_MITYC_TRUST_4 = "i18n.mityc.policy.mityc.4";

}
