/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */
package es.mityc.javasign.xml.xades.policy.facturae;

/** 
 * Constantes del módulo políticas de FacturaE.
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public final class ConstantsFacturaePolicy {
	
	/**
	 * Constructor.
	 */
	private ConstantsFacturaePolicy() { };
	
	/** Nombre de la librería. */
	public static final String LIB_NAME = "MITyCLibPolicy";

	/** Propiedad del algoritmo de hash. */
	public static final String PROPNAME_HASH_ID = "policy.digest.id.";
	/** Propiedad del valor del hash. */
	public static final String PROPNAME_HASH_VALUE = "policy.digest.value.";
	/** Propiedad de la uri del schema xades. */ 
	public static final String PROPNAME_SCHEMA_URI = "xades.schema.uri.";
	/** Propiedad del identificador de la política. */
	public static final String PROPNAME_POLICY_ID = "policy.id";
	/** Propiedad del identificador del validador. */
	public static final String PROPNAME_POLICY_ID_VALIDADOR = "policy.idValidator";
	/** Propiedad de la descripción del validador. */
	public static final String PROPNAME_POLICY_DESCRIPTION = "policy.description";
	/** Propiedad del digest del escritor. */
	public static final String PROPNAME_WRITER_HASH = "policy.writer.digest";
	
	// Contantes de internacionalización
	/** Error en la carga de la configuración del validador de facturae. */
	public static final String I18N_POLICY_FACTURAE_1 = "i18n.mityc.policy.facturae.1";
	/** Error en la configuración. */
	public static final String I18N_POLICY_FACTURAE_2 = "i18n.mityc.policy.facturae.2";
	/** Identificador de la policy indicada inválido. */
	public static final String I18N_POLICY_FACTURAE_3 = "i18n.mityc.policy.facturae.3";
	/** No hay descripción para esta policy: {0}. */
	public static final String I18N_POLICY_FACTURAE_4 = "i18n.mityc.policy.facturae.4";
	/** Error al indicar número de hash a escribir. */
	public static final String I18N_POLICY_FACTURAE_5 = "i18n.mityc.policy.facturae.5";
	/** No hay indicado hash para el escritor: {0}. */
	public static final String I18N_POLICY_FACTURAE_6 = "i18n.mityc.policy.facturae.6";
	/** No se pudo cargar la configuracion del validador. */
	public static final String I18N_POLICY_FACTURAE_7 = "i18n.mityc.policy.facturae.7";
	/** No hay configuración disponible. */
	public static final String I18N_POLICY_FACTURAE_8 = "i18n.mityc.policy.facturae.8";
	/** No se puede convertir ID de validador en mensaje de identidad. */
	public static final String I18N_POLICY_FACTURAE_9 = "i18n.mityc.policy.facturae.9";
	/** Versión de esquema XAdES no permitido. */
	public static final String I18N_POLICY_FACTURAE_10 = "i18n.mityc.policy.facturae.10";
	/** Huella de la política incorrecta. */
	public static final String I18N_POLICY_FACTURAE_11 = "i18n.mityc.policy.facturae.11";
	/** No se ha podido cargar fichero de configuración de validadores de facturae. */
	public static final String I18N_POLICY_FACTURAE_12 = "i18n.mityc.policy.facturae.12";
	/** No hay fichero de configuración disponible. */
	public static final String I18N_POLICY_FACTURAE_13 = "i18n.mityc.policy.facturae.13";
	/** No se ha encontrado política. */
	public static final String I18N_POLICY_FACTURAE_14 = "i18n.mityc.policy.facturae.14";
	/** La política encontrada es implícita. */
	public static final String I18N_POLICY_FACTURAE_15 = "i18n.mityc.policy.facturae.15";
	/** Error obteniendo digest/value de la policy. */
	public static final String I18N_POLICY_FACTURAE_16 = "i18n.mityc.policy.facturae.16";
	/** Algoritmo de hash de la policy no soportado. */
	public static final String I18N_POLICY_FACTURAE_17 = "i18n.mityc.policy.facturae.17";
	/** Configuración inadecuada para escribir la policy. */
	public static final String I18N_POLICY_FACTURAE_18 = "i18n.mityc.policy.facturae.18";
	/** Error en la configuración de escritura de la policy. */
	public static final String I18N_POLICY_FACTURAE_19 = "i18n.mityc.policy.facturae.19";
	/** No hay certificados disponibles para comprobar confianza. */
	public static final String I18N_POLICY_FACTURAE_20 = "i18n.mityc.policy.facturae.20";
	/** El certificado firmante no está recogido en los apartados a) ó c) del artículo 18 del Reglamento que está recogido en R.D. 1496/2003 del 28 de Noviembre.. */
	public static final String I18N_POLICY_FACTURAE_21 = "i18n.mityc.policy.facturae.21";
	/** No hay datos de firma para realizar la comprobación de roles. */
	public static final String I18N_POLICY_FACTURAE_22 = "i18n.mityc.policy.facturae.22";
	/** Rol no se ajusta a uno de los definidos en la política. */
	public static final String I18N_POLICY_FACTURAE_23 = "i18n.mityc.policy.facturae.23";
	/** No hay datos de firma para realizar la comprobación del esquema de firma. */
	public static final String I18N_POLICY_FACTURAE_24 = "i18n.mityc.policy.facturae.24";
	/** Esquema de firma no se ajusta a los definidos en la política. */
	public static final String I18N_POLICY_FACTURAE_25 = "i18n.mityc.policy.facturae.25";
	/** No se dispone de información del esquema para poder comprobar el hash de la política de firma. */
	public static final String I18N_POLICY_FACTURAE_26 = "i18n.mityc.policy.facturae.26";
	/** Error en los nodos XML que definen de política de firma. */
	public static final String I18N_POLICY_FACTURAE_27 = "i18n.mityc.policy.facturae.27";
	/** Hash de política de firma desconocido. */
	public static final String I18N_POLICY_FACTURAE_28 = "i18n.mityc.policy.facturae.28";
	/** Error en los nodos XML que definen de política de firma: {0}. */
	public static final String I18N_POLICY_FACTURAE_29 = "i18n.mityc.policy.facturae.29";
	/** No hay disponible un validador de confianza de entidades admitidas por MITyC. */
	public static final String I18N_POLICY_FACTURAE_30 = "i18n.mityc.policy.facturae.30";
	/** La factura no tiene forma enveloped. */
	public static final String I18N_POLICY_FACTURAE_31 = "i18n.mityc.policy.facturae.31";
	/** El certificado firmante no se encuentra disponible en el nodo KeyInfo. */
	public static final String I18N_POLICY_FACTURAE_32 = "i18n.mityc.policy.facturae.32";
	/** La transformada produce una estructura que se desconoce si es una enveloped aceptada. */
	public static final String I18N_POLICY_FACTURAE_33 = "i18n.mityc.policy.facturae.33";
	/** La transformada produce cambios en el nodo de certificado de firma que se desconoce si altera su contenido. */
	public static final String I18N_POLICY_FACTURAE_34 = "i18n.mityc.policy.facturae.34";
}
