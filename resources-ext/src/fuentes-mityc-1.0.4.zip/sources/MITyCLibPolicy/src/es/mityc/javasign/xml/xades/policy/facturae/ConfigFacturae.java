/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */
package es.mityc.javasign.xml.xades.policy.facturae;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.MissingResourceException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.mityc.firmaJava.libreria.xades.elementos.xades.DigestAlgAndValueType;
import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
import es.mityc.javasign.i18n.I18nFactory;
import es.mityc.javasign.i18n.II18nManager;

/**
 * <p>Esta clase centraliza la configuración de funcionamiento de un validador de política de factura-e.</p>
 *  
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class ConfigFacturae {
	/** Logger. */
	private static final Log LOG = LogFactory.getLog(ConfigFacturae.class);
	/** Internacionalizador. */
	private static final II18nManager I18N = I18nFactory.getI18nManager(ConstantsFacturaePolicy.LIB_NAME);

	/** Punto. */
	private static final String STRING_POINT = ".";
	/** Cadena vacía. */
	private static final String STRING_EMPTY = "";

	/** Identificador de la policy que se espera encontrar en la firma. */
	private URI policyIdXades = null;
	/** Cadena de identificación de la policy. */ 
	private String policyIdValidador = null;
	/** Cadena de descripción de la policy. */
	private String policyDescription = null;
	/** Hash's que se consideran válidos de la policy. */
	private ArrayList<DigestAlgAndValueType> huellas = null;
	/** Número de digest que utilizar para el escritor de policy. */
	private int policyWriterId = -1;

	
	/**
	 * <p>Constrcutor.</p>
	 * @param props Propiedades de configuración
	 * @param prefix Prefijo de propiedades que afectan a esta configuración
	 * @throws ConfigFacturaeException Lanzada cuando faltan datos de configuración o están mal formados
	 */
	public ConfigFacturae(final Properties props, final String prefix) throws ConfigFacturaeException {
		String prep = STRING_EMPTY;
		if ((prefix != null) && (!STRING_EMPTY.equals(prefix.trim()))) {
			prep = prefix + STRING_POINT;
		}
		// carga los datos de identidad
		try  {
			String policyIdXadesStr = props.getProperty(prep + ConstantsFacturaePolicy.PROPNAME_POLICY_ID);
			policyIdValidador = props.getProperty(prep + ConstantsFacturaePolicy.PROPNAME_POLICY_ID_VALIDADOR);
			if ((policyIdXadesStr == null) || (policyIdValidador == null)) {
				LOG.fatal(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_1));
				throw new ConfigFacturaeException(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_2));
			}
			policyIdXades = new URI(policyIdXadesStr);
		} catch (URISyntaxException ex) {
			LOG.fatal(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_3));
			throw new ConfigFacturaeException(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_2), ex);
		}
		// carga la descripcion de la policy
		try  {
			policyDescription = props.getProperty(prep + ConstantsFacturaePolicy.PROPNAME_POLICY_ID_VALIDADOR);
		} catch (MissingResourceException ex) {
			if (LOG.isTraceEnabled()) {
				LOG.trace(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_4, prep));
			}
		}
		// Carga la huellas
		huellas = new ArrayList<DigestAlgAndValueType>();
		int i = 0;
		while (true) {
			String hashId = props.getProperty(prep + ConstantsFacturaePolicy.PROPNAME_HASH_ID + i);
			String hashValue = props.getProperty(prep + ConstantsFacturaePolicy.PROPNAME_HASH_VALUE + i);
			if ((hashId != null) && (hashValue != null)) {
				huellas.add(new SigPolicyHash(null, hashId, hashValue));
				i++;
			} else {
				break;
			}
		}
		// carga el número de hash que se utilizará en el escritor 
		try  {
			String policyWriterIdStr = props.getProperty(prep + ConstantsFacturaePolicy.PROPNAME_WRITER_HASH);
			if (policyWriterIdStr == null) {
				if (LOG.isTraceEnabled()) {
					LOG.trace(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_6, prep));
				}
			} else {
				policyWriterId = Integer.parseInt(policyWriterIdStr);
				if (policyWriterId >= huellas.size()) {
					policyWriterId = -1;
					LOG.error(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_5));
				}
			}
		} catch (NumberFormatException ex) {
			LOG.error(I18N.getLocalMessage(ConstantsFacturaePolicy.I18N_POLICY_FACTURAE_5), ex);
		}
	}
	
	/**
	 * Devuelve la URI que identifica esta política.
	 * @return policyIdXades
	 */
	public URI getPolicyIdXades() {
		return policyIdXades;
	}
	
	/**
	 * Devuelve una cadena que identifica al manager.
	 * @return policyIdValidador
	 */
	public String getPolicyIdValidador() {
		return policyIdValidador;
	}

	/**
	 * Devuelve una cadena descriptiva de la política.
	 * @return policyDescription
	 */
	public String getPolicyDescription() {
		return policyDescription;
	}
	
	/**
	 * Devuelve el número de hash de los configurados configurado.
	 * @return policyWriterId
	 */
	public int getPolicyWriterId() {
		return policyWriterId;
	}
	
	/**
	 * Huellas configuradas que identifican la política.
	 * @return huellas
	 */
	public ArrayList<DigestAlgAndValueType> getHuellas() {
		return huellas;
	}
}
