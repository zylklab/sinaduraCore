/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.firmaJava;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import static org.junit.Assert.fail;

import es.mityc.firmaJava.libreria.xades.ExtraValidators;
import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
import es.mityc.firmaJava.libreria.xades.ValidarFirmaXML;
import es.mityc.javasign.xml.xades.policy.IValidacionPolicy;

/**
 * <p>Métodos base para la carga y validación de firmas.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public abstract class ValidationBase {
	
	/** Logger. */
	private static final Log LOGGER = LogFactory.getLog(ValidationBase.class);
	
	/**
	 * <p>Carga un recurso del classpath.</p>
	 * <p>Si no encuentra el recurso hace que falle el test.</p>
	 * @param path ruta al recurso
	 * @return Stream de lectura para el recurso
	 */
	protected InputStream loadRes(final String path) {
		InputStream is = this.getClass().getResourceAsStream(path);
		if (is == null) {
			fail("El recurso indicado (" + path + ") no está disponible");
		}
		return is;
	}
	
	/**
	 * <p>Devuelve en una cadena la ruta al recurso indicado.</p>
	 * <p>Si no encuentra el recurso hace que falle el test.</p>
	 * @param path Ruta al recurso
	 * @return cadena con la ruta del recurso
	 */
	protected String getBaseUri(final String path) {
		URL url = this.getClass().getResource(path);
		if (url == null) {
			fail("El recurso indicado (" + path + ") no está disponible");
		}
		return url.toString();
	}

	/**
	 * <p>Carga un fichero que está disponible en la ruta indicada.</p>
	 * <p>Si no se encuentra el fichero hace que falle el test.</p>
	 * @param ruta Ruta al fichero
	 * @return Fichero indicado
	 */
	protected File cargaFichero(final String ruta) {
		File file = new File(ruta);
		if (!file.exists()) {
			fail("Fichero indicado no existe: " + ruta);
		}
		return file;
	}
	
	/**
	 * <p>Valida un fichero que contiene una firma.</p>
	 * @param file Fichero con el xml a validar
	 * @param policy Política de firma que aplicar, <code>null</code> si no se quiere aplicar explícitamente ninguna
	 * @return resultado de la validación de la primera firma
	 */
	protected boolean validaFichero(final File file, final IValidacionPolicy policy) {
		try {
			ArrayList<IValidacionPolicy> policies = null;
			if (policy != null) {
				policies = new ArrayList<IValidacionPolicy>(1);
				policies.add(policy);
			}
			ValidarFirmaXML vXml = new ValidarFirmaXML();
			ExtraValidators extra = new ExtraValidators(policies, null, null);
			List<ResultadoValidacion> results = vXml.validar(file, extra);
			return results.get(0).isValidate();
		} catch (Exception ex) {
			LOGGER.info(ex.getMessage());
			LOGGER.info("", ex);
		}
		return false;
	}

	/**
	 * <p>Valida una firma.</p>
	 * @param is Stream con acceso al xml a validar
	 * @param baseUri uri base desde la que se buscarán los posibles elementos extra asociados con la firma
	 * @param policy Política de firma que aplicar, <code>null</code> si no se quiere aplicar explícitamente ninguna
	 * @return resultado de la validación de la primera firma
	 */
	protected boolean validateStream(final InputStream is, final String baseUri, final IValidacionPolicy policy) {
		try {
			ArrayList<IValidacionPolicy> policies = null;
			if (policy != null) {
				policies = new ArrayList<IValidacionPolicy>(1);
				policies.add(policy);
			}
			ValidarFirmaXML vXml = new ValidarFirmaXML();
			ExtraValidators extra = new ExtraValidators(policies, null, null);
			List<ResultadoValidacion> results = vXml.validar(is, baseUri, extra);
			return results.get(0).isValidate();
		} catch (Exception ex) {
			LOGGER.info(ex.getMessage());
			LOGGER.info("", ex);
		}
		return false;
	}

}
