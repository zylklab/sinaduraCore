/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.firmaJava;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

import junit.framework.JUnit4TestAdapter;

/**
 * <p>Batería de test para validar policies.</p>
 * <p>Se validan las siguientes policies:
 * <ul>
 *   <li>Factura Electrónica v3.0</li>
 * </ul></p>
 */
public class TestValidaPolicy extends ValidationBase {

	/** Factura electrónica de tipo Facturae v3.0 válida. */
	private static final String RES_FACTURAE_30 = "/FacturaE/factura2_ejemplo30.xml";

	/**
	 * <p>Comprueba que una factura v3.0 es validad correctamente.</p>
	 */
	@Test public final void validaFacturaE30() {
		assertTrue("Firma de FacturaE v3.0 no validada", validateStream(loadRes(RES_FACTURAE_30), null, null));
	}

	/**
	 * <p>Suite para lanzar los tests de factuirae 3.0.</p>
	 * @return Suite de facturae 3.0
	 */
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(TestValidaPolicy.class);
	}

}
