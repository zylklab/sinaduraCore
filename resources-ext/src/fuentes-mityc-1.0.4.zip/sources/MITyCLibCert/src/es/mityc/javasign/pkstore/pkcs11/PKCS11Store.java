/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.pkcs11;

import java.security.PrivateKey;
import java.security.Provider;
import java.security.cert.CertPath;
import java.security.cert.X509Certificate;
import java.util.List;

import es.mityc.javasign.pkstore.CertStoreException;
import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.IPassStoreKS;

/**
 * Wrapper para permitir utilizar los servicios de un dispositivo PKCS#11 (acceso a los servicios criptográficos de un dispositivo externo).
 *  
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class PKCS11Store implements IPKStoreManager {
	
	/**
	 * <p>Crea una instancia relacionándola con un dispositivo PKCS#11.</p>
	 * 
	 * @param libpath Ruta donde se encuentra la librería de sistema PKCS#11 que da acceso al dispositivo
	 * @param passHandler Manejador que servirá para recuperar las claves del dispositivo
	 */
	public PKCS11Store(final String libpath, IPassStoreKS passHandler) {
		// TODO: establece la ruta de la librería nativa de acceso al dispositivo PKCS#11. Instancia un provider SunPKCS11 adecuado
	}
	
	/**
	 * <p>Obtiene la cadena de certificados asociada al certificado indicado.</p>
	 * 
	 * No implementado
	 * 
	 * @param certificate Certificado base de la cadena
	 * @return No implementado
	 * @throws CertStoreException Lanzada cuando hay problemas en la construcción de la cadena de certificados según los certificados del dispositivo PKCS#11
	 */
	public CertPath getCertPath(final X509Certificate certificate) throws CertStoreException {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * <p>Obtiene un wrapper de acceso a la clave privada asociada al certificado indicado.</p>
	 * 
	 * @param certificate Certificado del que se requiere la clave privada
	 * @return Clave privada asociada al certificado
	 * @throws CertStoreException Lanzada cuando hay problemas en el acceso a una clave privada del dispositivo PKCS#11
	 */
	public PrivateKey getPrivateKey(final X509Certificate certificate) throws CertStoreException {
		// TODO: accede al Keystore del provider asociado al dispositivo y pide la clave asociada al certificado (buscando por alias).
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * <p>Se devuelve el provider que da acceso a las capacidades criptográficas del dispositivo relacionado.</p>
     * @param certificate Certificado para el que se necesita acceso al provider
	 * @return provider asociado al dispositivo
	 */
	public Provider getProvider(final X509Certificate certificate) {
		// TODO: devolver el provider asociado al dispositivo
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * <p>Devuelve los certificados que tienen asociado clave privada.</p>
	 * 
	 * @return Lista con los certificados que tienen clave privada
	 * @throws CertStoreException Lanzada cuando no se tiene acceso a los certificados de firma
	 */
	public List<X509Certificate> getSignCertificates() throws CertStoreException {
		// TODO: accede al KeyStore del provider asociado al dispositivo y pide los elementos que son PrivateKeyEntry
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * <p>Devuelve los certificados de confianza disponibles en el dispositivo externo.</p>
	 * 
	 * @return certificados de confianza disponibles en el dispositivo 
	 * @throws CertStoreException Lanzada cuando no se tiene acceso a certificados de confianza del dispositivo
	 */
	public List<X509Certificate> getTrustCertificates() throws CertStoreException {
		// TODO: accede al KeyStore del provider asociado al dispositivo y pide los elementos que son TrustedCertificateEntry
		throw new UnsupportedOperationException("Not implemented yet");
	}

}
