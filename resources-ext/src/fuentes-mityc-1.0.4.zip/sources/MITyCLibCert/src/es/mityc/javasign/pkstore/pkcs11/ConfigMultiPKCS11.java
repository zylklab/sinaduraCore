/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.pkcs11;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import java.util.List;

import es.mityc.javasign.i18n.I18nFactory;
import es.mityc.javasign.i18n.II18nManager;
import es.mityc.javasign.pkstore.ConstantsCert;

/**
 * <p>Configuración de proveedores de acceso a PKCS#11.</p>
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class ConfigMultiPKCS11 {
	/** Lista de providers disponibles en esta configuración. */
	private ArrayList<IModuleData> providers = new ArrayList<IModuleData>();
	/** Internacionalizador. */
	private static final II18nManager I18N = I18nFactory.getI18nManager(ConstantsCert.LIB_NAME);
	
	/** Nombre del módulo que conecta con las clases de SunPKCS11. */
	private static final String MODULE_CLASS = "es.mityc.javasign.pkstore.pkcs11.SunP11ModuleData";
	/** Nombre de la clase provider de Sun para módulos PKCS 11. */
	private static final String SUN_CLASS = "sun.security.pkcs11.SunPKCS11";

	/**
	 * <p>Constructor.</p> 
	 */
	public ConfigMultiPKCS11() {
	}
	
	/**
	 * <p>Añade un nuevo provider del tipo Sun para el acceso a módulos PKCS#11.</p>
	 * @param name Nombre del módulo PKCS#11
	 * @param lib Ruta de la librería PKCS#11
	 * @throws NoSuchProviderException lanzada si no se encuentran las clases de SunPKCS11
	 */
	public void addSunProvider(final String name, final String lib) throws NoSuchProviderException {
		testSunPKCS11Library();
		providers.add(getSunP11ModuleData(name, lib));
	}
	
	/**
	 * <p>Instancia de nabera dinámica el módulo P11 de Sun.</p>
	 * @param name Nombre del proveedor 
	 * @param lib Librería P11 de acceso al módulo
	 * @return Módulo P11
	 * @throws NoSuchProviderException lanzada si no se encuentran las clases de SunPKCS11
	 */
	private IModuleData getSunP11ModuleData(final String name, final String lib) throws NoSuchProviderException {
		try {
			Class< ? > prov = Class.forName(MODULE_CLASS);
			Constructor< ? > constructor = prov.getConstructor(String.class, String.class);
			return (IModuleData) constructor.newInstance(name, lib);
		} catch (ClassNotFoundException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		} catch (SecurityException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		} catch (NoSuchMethodException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		} catch (IllegalArgumentException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		} catch (InstantiationException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		} catch (IllegalAccessException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		} catch (InvocationTargetException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));
		}
	}
	
	/**
	 * <p>Comprueba si la librería de sunpkcs11 está disponible.</p>
	 * <p>Si la librería no está disponible lanza una excepción del tipo ProviderException.</p>
	 * @throws NoSuchProviderException lanzada si no se encuentran las clases de SunPKCS11 
	 */
	public void testSunPKCS11Library() throws NoSuchProviderException {
		try {
			Class< ? > prov = Class.forName(SUN_CLASS);
			if (prov == null) {
				throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_17)));
			}
		} catch (ClassNotFoundException ex) {
			throw new NoSuchProviderException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_PKCS11_16, ex.getMessage()));		
		}
	}

	
	/**
	 * <p>Devuelve la lista de providers configurado.</p>
	 * @return lista de providers
	 */
	protected List<IModuleData> getProviders() {
		return providers;
	}
}
