/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.iexplorer;

import java.security.AccessController;
import java.security.PrivilegedAction;

import es.mityc.javasign.pkstore.ConstantsCert;

/**
 * Clase JNI para el acceso al CSP de Windows.
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */

public final class IECSPJNI  {
    
    /**
     * <p>Firma un hash mediante un certificado.</p>
     * @param paraFirmar datos en binario a firmar
     * @param certificadoBinario certificado en binario que realizará la firma
     * @return contenido firmado
     */
	public native byte[] signHash(byte[] paraFirmar, byte[] certificadoBinario);
    /**
     * <p>Recupera los certificados de un almacén en forma binaria.</p>
     * @param almacenaNombre nombre del almacén interno de windows
     * @return array de certificados en binario disponibles en el almacén
     */
	public native byte[][] getCertificatesInSystemStore(String almacenaNombre);
    /**
     * <p>Recupera el DN del issuer de un certificado.</p>
     * @param certificado certificado en binario
     * @return cadena con el DN del issuer
     */
	public native String getIssuerDN(byte[] certificado);
    /**
     * <p>Obtiene el número serie del certificado.</p>
     * @param certificado certificado en binarios
     * @return número serie en binario
     */
    public native byte[] getSerialNumber(byte[] certificado);
    /**
     * <p>Obtiene el DN del subject de un certificado.
     * @param certificado certificado en binario
     * @return cadena con el DN del subject
     */
    public native String getSubjectDn(byte[] certificado);
    
    
    /**
     * <p>Devuelve el último error que se produjo en la librería DLL externa.</p>
     * @return Número entero que especifíca el tipo de error según la lista siguiente,
     * definida en la DLL externa basada en OPENSIGN
     * <CODE>#define OPENSIGN_ERROR_NONE 0
     * #define OPENSIGN_ERROR_DIGEST_VALUE_UNAVAILABLE 1
     * #define OPENSIGN_ERROR_DIGEST_SIZE_UNAVAILABLE 2
     * #define OPENSIGN_ERROR_HHASH_DESTROY_FAILURE 3
     * #define OPENSIGN_ERROR_HHASH_CREATE_FAILURE 4
     * #define OPENSIGN_ERROR_HCRYPTPROV_RELEASE_FAILURE 5
     * #define OPENSIGN_ERROR_HCRYPTPROV_ACQUIRE_FAILURE 6
     * #define OPENSIGN_ERROR_CERTSTORE_OPEN_FAILURE 7
     * #define OPENSIGN_ERROR_CERTSTORE_CERTIFICATE_NOT_FOUND 8
     * #define OPENSIGN_ERROR_CERTSTORE_CLOSE_FAILURE 9
     * #define OPENSIGN_ERROR_CCONTEXT_PROVINFO_VALUE_UNAVAILABLE 10
     * #define OPENSIGN_ERROR_HHASH_SIGNATURE_VALUE_UNAVAILABLE 11
     * #define OPENSIGN_ERROR_HHASH_SIGNATURE_SIZE_UNAVAILABLE 13
     * #define OPENSIGN_ERROR_CCONTEXT_PROVINFO_SIZE_UNAVAILABLE 14
     * #define OPENSIGN_ERROR_HHASH_HASHDATA_FAILURE 15
     * #define OPENSIGN_ERROR_CERTGETNAMESTRING_SIZE_FAILURE 16
     * #define OPENSIGN_ERROR_CERTGETNAMESTRING_VALUE_FAILURE 17
     * #define OPENSIGN_ERROR_MEMORY_ALLOCATION_FAILURE 18
     * #define OPENSIGN_ERROR_KEYUSAGE_NOT_PRESENT 19</CODE>
     */
    public native int getLastErrorCode();
    
    
    /**
     * <p>Crea una nueva instancia de FirmaMS.</p>
     */
    public IECSPJNI() {
        AccessController.doPrivileged(new PrivilegedAction<Object>() {
            public Object run() {
            	System.loadLibrary(ConstantsCert.CSP_JNI_IE);
                return null;
            }
        });
    }
}
