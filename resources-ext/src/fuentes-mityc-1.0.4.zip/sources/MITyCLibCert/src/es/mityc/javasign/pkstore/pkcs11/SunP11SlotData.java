/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */

package es.mityc.javasign.pkstore.pkcs11;

import java.security.Provider;

/**
 * <p>Relación entre Provider específico de PKCS11 y el slot asociado.</p>
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class SunP11SlotData implements IProviderData {

	/** Proveedor asociado. */
	private Provider provider;
	/** SlotID asociado en el proveedor. */
	private long slotID;
	/** Nombre del tipo de KeyStore que maneja este proveedor. */
	private String keyStoreType;
	
	/**
	 * <p>Constructor.</p>
	 * @param prov Provider de PKCS11
	 * @param slot SlotID asociado al provider
	 * @param type Nombre del tipo de KeyStore manejado por este proveedor
	 */
	public SunP11SlotData(Provider prov, long slot, String type) {
		this.provider = prov;
		this.slotID = slot;
		this.keyStoreType = new String(type);
	}
	
	/**
	 * <p>Devuelve el slotID.</p>
	 * @return slotID
	 */
	public long getSlotID() {
		return slotID;
	}
	
	/**
	 * <p>Devuelve el provider.</p>
	 * @return Provider
	 */
	public Provider getProvider() {
		return provider;
	}
	
	/**
	 * <p>Devuelve el tipo de KeyStore que gestiona el provider de este slot.</p>
	 * @return Cadena con el tipo de KeyStore
	 */
	public String getKeyStoreTypeName() {
		return keyStoreType;
	}
	
	/**
	 * <p>Compara exclusivamente a través del slotID asociado.</p>
	 * @param obj Objeto a comparar
	 * @return <code>true</code> si tienen el mismo slotID, <code>false</code> en otro caso
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
		if (obj instanceof SunP11SlotData) {
			if (slotID == ((SunP11SlotData) obj).slotID) {
				return true;
			}
		} else if (obj instanceof Long) {
			if (slotID == ((Long) obj).longValue()) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * <p>El hashCode de este elemento depende únicamnete de su SlotID.</p>
	 * @return HashCode del slotId
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return (int) (slotID ^ (slotID >>> 32));
	}
}
