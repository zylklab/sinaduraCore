/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.mozilla;

import java.io.ByteArrayInputStream;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertPath;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mozilla.jss.CertDatabaseException;
import org.mozilla.jss.CryptoManager;
import org.mozilla.jss.JSSProvider;
import org.mozilla.jss.KeyDatabaseException;
import org.mozilla.jss.CryptoManager.NotInitializedException;
import org.mozilla.jss.asn1.INTEGER;
import org.mozilla.jss.crypto.AlreadyInitializedException;
import org.mozilla.jss.crypto.CryptoStore;
import org.mozilla.jss.crypto.ObjectNotFoundException;
import org.mozilla.jss.crypto.TokenException;
import org.mozilla.jss.pkcs11.PK11Module;
import org.mozilla.jss.pkcs11.PK11Token;
import org.mozilla.jss.util.IncorrectPasswordException;
import org.mozilla.jss.util.PasswordCallback;

import es.mityc.javasign.exception.CopyFileException;
import es.mityc.javasign.i18n.I18nFactory;
import es.mityc.javasign.i18n.II18nManager;
import es.mityc.javasign.pkstore.CertStoreException;
import es.mityc.javasign.pkstore.ConstantsCert;
import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.mozilla.IPINDialogConfigurable.MESSAGES_MODE;
import es.mityc.javasign.utils.CopyFilesTool;

/**
 * <p>Facade de acceso a los servicios del almacén de certificados de Mozilla mediante el uso de JSS.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class MozillaStore implements IPKStoreManager {
	
	/** Logger. */
	private static final Log LOG = LogFactory.getLog(MozillaStore.class);
	/** Internacionalizador. */
	private static final II18nManager I18N = I18nFactory.getI18nManager(ConstantsCert.LIB_NAME);

	/** Modos de inicialización de la librería jss. */
	public enum LIB_MODE { FULL, ONLY_JSS };
    /** Indica si la conexión con la parte nativa ya se ha producido. */
	private static boolean isNativeInitialized = false;
    
	/** Nombre del recurso que contiene la configuración. */
	private static final String STR_MOZILLA = "mozilla";
	/** Nombre de la propiedad que indica la clase que se utiliza para recoger contraseñas. */
    private static final String STR_PASS_HANDLER = "passCallbackHandler";
    /** Nombre dle módulo que gestiona el almacén interno de Mozilla. */
    private static final String STR_FIX_JSS_BUILT_IN = "Builtin Object Token";

	/** Mananger general de las funciones criptográficas de Mozilla. */
	private static CryptoManager cm;
	/** Modo de funcionamiento de login de los tokens. */
	private MozillaTokenLoginModeEnum loginMode = MozillaTokenLoginModeEnum.getDefault();
	/** Tiempo en minutos de espera antes de tener que volver a logar en caso de que los tokens se desactiven por tiempo. */
	private int loginTimeoutMinutes = 5;
	
	/**
	 * Constructor. En la inicialización Hay que indicar el nombre del almacén
	 * @param profile Ruta donde se encuentra el perfil de usuario de Mozilla
	 */
	public MozillaStore(String profile) {
		this(profile, LIB_MODE.FULL);
	}
	
	/**
	 * Constructor. En la inicialización Hay que indicar el nombre del almacén
	 * @param profile Ruta donde se encuentra el perfil de usuario de Mozilla
	 * @param mode Indica el modo en el que se copiarán las librerías nativas
	 */
	public MozillaStore(String profile, LIB_MODE mode) {
		initializeJSS(profile, mode);
	}

	/**
	 * @see es.mityc.javasign.pkstore.IPKStoreManager#getCertPath(java.security.cert.X509Certificate)
	 */
	public CertPath getCertPath(X509Certificate certificate) throws CertStoreException {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	/**
	 * @see es.mityc.javasign.pkstore.IPKStoreManager#getPrivateKey(java.security.cert.X509Certificate)
	 */
	public PrivateKey getPrivateKey(X509Certificate certificate) throws CertStoreException {
		try {
			org.mozilla.jss.crypto.X509Certificate certJSS = cm.findCertByIssuerAndSerialNumber(certificate.getIssuerX500Principal().getEncoded(), new INTEGER(certificate.getSerialNumber()));
			return cm.findPrivKeyByCert(certJSS);
		} catch (ObjectNotFoundException ex) {
			throw new CertStoreException(ex);
		} catch (TokenException ex) {
			throw new CertStoreException(ex);
		}
	}

	/**
     * @param cert Certificado para el que se necesita acceso al provider
     * @return Provider asociado a este almacén
	 * @see es.mityc.javasign.pkstore.IPKStoreManager#getProvider(X509Certificate)
	 */
	public Provider getProvider(final X509Certificate cert) {
		return new JSSProvider();
	}

	/**
	 * @see es.mityc.javasign.pkstore.IPKStoreManager#getSignCertificates()
	 */
	public List<X509Certificate> getSignCertificates() throws CertStoreException {
        ArrayList<X509Certificate> allCerts = new ArrayList<X509Certificate>();
        if (cm != null) {
	        try {
	            // Recoge los tokens externos y les da a cada uno un passwordcallback que indica el nombre del dispositivo
	            Enumeration< ? > enModules = cm.getModules();
	            boolean modulesHasMore = enModules.hasMoreElements();
	            while (modulesHasMore) {
	            	if (LOG.isTraceEnabled()) {
						LOG.trace("Procesando modulo PK11 de mozilla");
	            	}
	            	PK11Module module = (PK11Module) enModules.nextElement();
	            	if (LOG.isTraceEnabled()) {
						LOG.trace("Modulo: " + module.getName());
					}
	            	modulesHasMore = enModules.hasMoreElements();
	            	if (LOG.isTraceEnabled()) {
						LOG.trace("Recargando tokens");
	            	}
	            	module.reloadTokens();
	            	if (LOG.isTraceEnabled()) {
						LOG.trace("Tokens recargados");
	            	}
	    			Enumeration< ? > enTok = module.getTokens();
	    			if (LOG.isTraceEnabled()) {
						LOG.trace("Tokens del módulo obtenidos");
	    			}
	    			boolean tokHasMore = enTok.hasMoreElements();
	            	while (tokHasMore) {
	            		if (LOG.isTraceEnabled()) {
	    					LOG.trace("Procesando token");
	            		}
	            		PK11Token token = (PK11Token) enTok.nextElement();
	            		if (LOG.isTraceEnabled()) {
	    					LOG.trace("Token: " + token.getName());
	    				}
	            		tokHasMore = enTok.hasMoreElements();
	            		
	            		// Fix para el error de las librerías JSS de Linux
	            		if (STR_FIX_JSS_BUILT_IN.equals(token.getName())) {
	            			continue;
	            		}
	            		
	            		if ((!token.isInternalCryptoToken()) && (!token.isInternalKeyStorageToken())) {
	            			if (LOG.isTraceEnabled()) {
	        					LOG.trace("Procesando token externo");
	            			}
		            		if (token.isPresent()) {
		            			if (token.isLoggedIn()) {
		            				// Comprobar si la configuracion ha cambiado
		            				boolean doLogout = (loginMode != MozillaTokenLoginModeEnum.getLoginMode(token.getLoginMode()));
		            				if (!doLogout && loginMode == MozillaTokenLoginModeEnum.TIMEOUT) {
		            					doLogout = loginTimeoutMinutes != token.getLoginTimeoutMinutes();
		            				}
	
		            				// Si ha cambiado hacer un logout
		            				if (doLogout) {
		            					token.logout();
		            				}
		            			}
		            			if (!token.isLoggedIn()) {
		            				if (LOG.isTraceEnabled()) {
		            					LOG.trace("Loggin de token...");
		            				}
		            				int tries = 0;
		            				while (tries < 3) {
			            				try {
			            					token.setLoginMode(loginMode.getInteger());
			            					if (this.loginMode == MozillaTokenLoginModeEnum.TIMEOUT) {
			            						token.setLoginTimeoutMinutes(loginTimeoutMinutes);
			            					}
			            					token.login(getPassHandler(MESSAGES_MODE.AUTO_TOKEN, null, I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_8)));
			            					tries += 3;
			            					if (LOG.isTraceEnabled()) {
		                    					LOG.trace("Loggin de token correcto!");
			            					}
			            				} catch (IncorrectPasswordException ex) {
			            		        	LOG.info(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_6));
			            		        	tries++;
			            				} catch (TokenException ex) {
			            		        	LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_7, token.getName()), ex);
			            		        	tries++;
			            				}
		            				}
		            			}
		            			if (token.isLoggedIn()) {
		            				if (LOG.isTraceEnabled()) {
		            					LOG.trace("Accediendo a token...");
		            				}
		    	            		CryptoStore store = token.getCryptoStore();
		    	            		org.mozilla.jss.crypto.X509Certificate[] certs = store.getCertificates();
		    	            		for (int i = 0; i < certs.length; i++) {
		    	            			X509Certificate cert = convert(certs[i]);
		    	            			boolean[] usage = cert.getKeyUsage();
		    	            			// permite los certificados que tienen indicado como uso la firma digital o que no tienen indicado ningún permiso
		    	            			if ((cert != null) && ((usage == null) || (usage[0]) || (usage[1]))) {
		    	            				allCerts.add(cert);
		    	            			}
		    	            		}
		            			}
		            		}
	            		}
	            	}
	            	if (LOG.isTraceEnabled()) {
						LOG.trace("Modulo P11 procesado");
	            	}
	            }            
	
	            // Recoge todos los certificados que tienen una clave privada en el storage interno del mozilla
	            if (LOG.isTraceEnabled()) {
					LOG.trace("Pide certificados");
	            }
	    		org.mozilla.jss.crypto.X509Certificate[] certs = cm.getInternalKeyStorageToken().getCryptoStore().getCertificates();
	    		if (LOG.isTraceEnabled()) {
					if (certs != null) {
						LOG.trace("Se han obtenido " + certs.length + " certificados");
					} else {
						LOG.trace("No hay certificados disponibles");
					}
				}
	    		
	    		for (int i = 0; i < certs.length; i++) {
	    			try {
	    				if (LOG.isTraceEnabled()) {
	    					LOG.trace("Buscando clave privada para: " + certs[i]);
	    				}
		    			if (cm.findPrivKeyByCert(certs[i]) != null) {
			    			X509Certificate cert = convert(certs[i]);
			    			allCerts.add(cert);
		    			}
	    			} catch (ObjectNotFoundException ex) {
	    				if (LOG.isTraceEnabled()) {
	    					LOG.trace("No hay clave privada");
	    				}
	    			}
	    		}
	            
	        } catch (SecurityException ex) {
	        	// No se puede acceder al almacén de certificados de mozilla
	        	LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_9), ex);
	        	throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_9), ex);  
	        } catch (TokenException ex) {
	        	// No se puede acceder al almacén de certificados de mozilla
	        	LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_9), ex);
	        	throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_9), ex);  
			}
        }
        return allCerts;
	}

	/**
	 * @see es.mityc.javasign.pkstore.IPKStoreManager#getTrustCertificates()
	 */
	public List<X509Certificate> getTrustCertificates() throws CertStoreException {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	/**
	 *<p> Inicializa el manager general de JSS.</p>
	 * 
	 * @param profile ruta donde se encuentra el perfil de usuario
	 */
	private synchronized void initializeJSS(String profile, LIB_MODE mode) {
		if (!isNativeInitialized) {
			copyLibraries(mode);
	        try {
				CryptoManager.initialize(profile);
				cm = CryptoManager.getInstance();
				// Elimina el provider que inserta JSS para evitar conflictos
				Security.removeProvider(new JSSProvider().getName());
			} catch (KeyDatabaseException ex) {
				LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_2, ex.getMessage()), ex);
			} catch (CertDatabaseException ex) {
				LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_2, ex.getMessage()), ex);
			} catch (AlreadyInitializedException ex) {
			} catch (GeneralSecurityException ex) {
				LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_2, ex.getMessage()), ex);
			} catch (NotInitializedException ex) {
				LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_2, ex.getMessage()), ex);
			}
			if (cm != null) {
				cm.setPasswordCallback(getPassHandler(MESSAGES_MODE.AUTO, null, null));
				isNativeInitialized = true;
			}
		}
	}
	
    /**
     * <p>Copia las librerías de puente a mozilla.</p>
     */
    private synchronized void copyLibraries(LIB_MODE mode) {
		try {
			CopyFilesTool cft = new CopyFilesTool(ConstantsCert.CP_MZ_PROPERTIES, this.getClass().getClassLoader());
			switch (mode) {
				case FULL: cft.copyFilesOS(null, ConstantsCert.CP_MOZILLA_CLIENTE, true); break;
				case ONLY_JSS: cft.copyFilesOS(null, ConstantsCert.CP_MOZILLA_APPLET, true); break;
			}
			// precarga las librerías de mozilla
//    		if (OSTool.isOSLinux()) {
        		System.loadLibrary("nspr4");
        		System.loadLibrary("plds4");
        		System.loadLibrary("plc4");
//    		}
//    		else {
//        		System.loadLibrary("libnspr4");
//        		System.loadLibrary("libplds4");
//        		System.loadLibrary("libplc4");
//    		}
    		System.loadLibrary("softokn3");
    		System.loadLibrary("nss3");
    		System.loadLibrary("smime3");
    		System.loadLibrary("ssl3");
		} catch (SecurityException ex) {
			LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_1, ex.getMessage()), ex);
		} catch (UnsatisfiedLinkError ex) {
			LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_1, ex.getMessage()), ex);
		} catch (CopyFileException ex) {
			LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_1, ex.getMessage()), ex);
		} 
    }
    
    /**
     * <p>Carga la clase encargada de obtener las contraseñas pedidas por el almacén de Mozilla.</p>
     * 
     * @param mode Modo en el que se mostrarán los títulos en la ventana (@see {@link MESSAGES_MODE}}
     * @param title Título de la ventana de PIN
     * @param pinMessage Mensaje de petición de PIN
     * @return instancia de la clase configurada (instancia de {@link PassStoreMozilla} si no está correctamente configurado) 
     */
    private PasswordCallback getPassHandler(MESSAGES_MODE mode, String title, String pinMessage) {
    	PasswordCallback handler = null;
    	try {
    		if (LOG.isTraceEnabled()) {
    			LOG.trace("Obteniendo Passhandler...");
    		}
    		ResourceBundle rb = ResourceBundle.getBundle(STR_MOZILLA);
    		String handlerClass = rb.getString(STR_PASS_HANDLER);
    		if (LOG.isTraceEnabled()) {
    			LOG.trace("Nombre de ventana de pin: " + handlerClass);
    		}
    		handler = (PasswordCallback) Class.forName(handlerClass).newInstance();
    		((IPINDialogConfigurable) handler).setMessagesMode(mode);
    		if (title != null) {
    			((IPINDialogConfigurable) handler).setTitle(title);
    		}
    		if (pinMessage != null) {
    			((IPINDialogConfigurable) handler).setPINMessage(pinMessage);
    		}
    		if (LOG.isTraceEnabled()) {
    			LOG.trace("Pashandler configurado");
    		}
    	} catch (MissingResourceException ex) {
    		LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_3, ex.getMessage()));
    		handler = new PassStoreMozilla();
    	} catch (InstantiationException ex) {
    		LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_3, ex.getMessage()));
    		if (LOG.isDebugEnabled()) {
    			LOG.error(ex);
    		}
    		handler = new PassStoreMozilla();
		} catch (IllegalAccessException ex) {
    		LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_3, ex.getMessage()));
    		if (LOG.isDebugEnabled()) {
    			LOG.error(ex);
    		}
    		handler = new PassStoreMozilla();
		} catch (ClassNotFoundException ex) {
    		LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_3, ex.getMessage()));
    		if (LOG.isDebugEnabled()) {
    			LOG.error(ex);
    		}
    		handler = new PassStoreMozilla();
		} catch (ClassCastException ex) {
    		LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_3, ex.getMessage()));
    		if (LOG.isDebugEnabled()) {
    			LOG.error(ex);
    		}
    		handler = new PassStoreMozilla();
		}
    	return handler;
    }

    /**
     * <p>Convierte un certificado del tipo mozilla en uno de java (especie de typecasting).</p>
     * 
     * @param certificate el certificado en la clase org.mozilla.jss.crypto.X509Certificate
     * @return el certificado en la clase java.security.cert.X509Certificate, <code>null</code> si no lo consigue convertir
     */
    private X509Certificate convert(org.mozilla.jss.crypto.X509Certificate certificate) {
		try {
			byte[] certFirma = certificate.getEncoded();
	        CertificateFactory cf = CertificateFactory.getInstance("X.509");
	        return (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(certFirma));
		} catch (CertificateEncodingException ex) {
        	LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_4, ex.getMessage()), ex);
		} catch (CertificateException ex) {
        	LOG.error(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MOZILLA_4, ex.getMessage()), ex);
		}
		return null;
    }
    
	/**
	 * Returns the login mode: ONE_TIME, TIMEOUT, or EVERY_TIME. The default is ONE_TIME.
	 * @return modo de login
	 */
	public MozillaTokenLoginModeEnum getLoginMode() {
		return loginMode;
	}

	/**
	 * Sets the login mode of this token.
	 * @param mode ONE_TIME, TIMEOUT, or EVERY_TIME
	 */
	public void setLoginMode(MozillaTokenLoginModeEnum mode) {
		this.loginMode = mode;
	}

	/**
	 * Returns the login timeout period. The timeout is only used if the login mode is TIMEOUT.
	 * @return timeout de login en minutos 
	 */
	public int getLoginTimeoutMinutes() {
		return loginTimeoutMinutes;
	}

	/**
	 * Sets the timeout period for logging in. This will only be used if the login mode is TIMEOUT.
	 * @param timeoutMinutes
	 */
	public void setLoginTimeoutMinutes(int timeoutMinutes) {
		this.loginTimeoutMinutes = timeoutMinutes;
	}
}
