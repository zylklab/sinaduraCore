/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.mitycstore.mantainer;

import java.io.File;

import javax.swing.filechooser.FileFilter;

import es.mityc.javasign.i18n.I18nFactory;
import es.mityc.javasign.i18n.II18nManager;
import es.mityc.javasign.pkstore.ConstantsCert;

/**
* @author  Ministerio de Industria, Turismo y Comercio
* @version 1.0
*/
public class CertsFilter extends FileFilter {
    
	/** Internacionalizador. */
	private static final II18nManager I18N = I18nFactory.getI18nManager(ConstantsCert.LIB_NAME);
	/** Extensión para los contenedores PKCS12. */
	private static final String P12	= "p12";
	/** Extensión para certificados. */
	private static final String CER	= "cer";
	/** Extensión para certificados. */
	private static final String CRT	= "crt";
	/** Caracter de separación entre nombre y extensión. */
    private static final char CHAR_DOT = '.';
    /** Booleano para indicar si el certificado debe estar asociado a una clave privada. */
    private boolean isSign = false;
    
    /**
     * <p>Constructor del filtro para certificados.</p>
     * @param isCertForSign <p>Parámetro que indica si el filtro es para certificados de firma o de autenticación.
     * 		  <code>true</code> indica que es certificado de firma, por lo que se incluyen las extensiones P12.</p>
     */
    public CertsFilter(boolean isCertForSign) {
    	super();
    	this.isSign = isCertForSign;
    }
    
    /**
     * <p>Este método filtra las extensiones de los ficheros que contienen certificados.</p>
     * @param f Fichero o directorio a filtrar
     * @return <code>true</code> indica que se pasa el filtro.
     */    
    public boolean accept(final File f) {

        if (f.isDirectory()) {
            return true;
        }

        String s = f.getName();
        int i = s.lastIndexOf(CHAR_DOT);

        if (i > 0  &&  i < s.length() - 1) {
            String extension = s.substring(i + 1).toLowerCase();
            if (P12.equals(extension) && isSign) {
            	return true;
            } else if (CER.equals(extension)) {
                return true;
            } else if (CRT.equals(extension)) {
            	return true;
            } else {
                return false;
            }
        }

        return false;
    }
    
    
    /**
     * <p>Descripción del filtro de certificados.</p>
     * @return Se devuelve el nombre a mostrar para el filtro
     */
    public String getDescription() {
    	// Certificados
    	return I18N.getLocalMessage(ConstantsCert.I18N_CERT_MITYC_46);
    }
}
