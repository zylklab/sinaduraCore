/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.mitycstore.mantainer;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * <p>Renderizador de las celdas para las tablas de certificados.</p> 
 *  
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class CertCellRenderer extends DefaultTableCellRenderer {
	
	/**
	 * <p>Devuelve la clase encargada de dibujar la celda correspondiente.</p>
	 * <p>El comportamiento es el mismo que por defecto, salvo por la alineación y el tooltip.</p>
	 * 
	 * @param table Tabla a la que la ceda pertenece
	 * @param value Valor contenido dentro de la celda
	 * @param isSelected Booleano que indica si la celda está marcada como seleccionada
	 * @param hasFocus Booleano que indica si la tabla tiene el foco
	 * @param row Numero de fila (empezando por el 0)
	 * @param column Número de columna (empezando por el 0)
	 * @return Devuelve una instancia a ésta misma clase 
	 */
	public Component getTableCellRendererComponent(
			final JTable table,
			final Object value,
			final boolean isSelected,
			final boolean hasFocus,
			final int row,
			final int column) { 
		
		super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		
		// ToolTip
		 setToolTipText((String) value);
		
		 // Allignment
		if (column == 0) {
			setHorizontalAlignment(SwingConstants.LEFT);
		} else if (column == 1) {
			setHorizontalAlignment(SwingConstants.LEFT);
		} else	if (column == 2) {
			setHorizontalAlignment(SwingConstants.CENTER);
		} 
				
		return this; 
	} 
}
