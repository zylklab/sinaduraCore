/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.keystore;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

import es.mityc.javasign.i18n.I18nFactory;
import es.mityc.javasign.i18n.II18nManager;
import es.mityc.javasign.pkstore.ConstantsCert;
import es.mityc.javasign.pkstore.IPassStoreKS;

/**
 * <p>Wrapper necesario para KeyStore para la obtención de contraseñas según el interfaz {@link IPassStoreKS}.</p>
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class PassCallbackHandlerProtection implements CallbackHandler {

	/** Internacionalizador. */
	private static final II18nManager I18N = I18nFactory.getI18nManager(ConstantsCert.LIB_NAME);

	/** Manejador de las contraseñas. */
	private IPassStoreKS passHandler;
	
	/**
	 * <p>Constructor.</p>
	 * @param passwordHandler manejador de las contraseñas 
	 */
	public PassCallbackHandlerProtection(IPassStoreKS passwordHandler) {
		this.passHandler = passwordHandler;
	}
	
	/**
	 * <p>Maneja las consultas de acceso a contraseñas.</p>
	 * @param callbacks Peticiones de contraseñas recibidas
	 * @throws IOException Lanzada si hay errores en el acceso a la contraseña
	 * @throws UnsupportedCallbackException Lanzada si el tipo de Callback recibido no se aplica
	 * @see javax.security.auth.callback.CallbackHandler#handle(javax.security.auth.callback.Callback[])
	 */
	public void handle(final Callback[] callbacks) throws IOException, UnsupportedCallbackException {
		for (int i = 0; i < callbacks.length; i++) {
			if ((passHandler != null) &&
				(callbacks[i] instanceof PasswordCallback)) {
                 PasswordCallback pc = (PasswordCallback) callbacks[i];
                 pc.setPassword(passHandler.getPassword(null, pc.getPrompt()));
             } else {
                 throw new UnsupportedCallbackException(callbacks[i], I18N.getLocalMessage(ConstantsCert.I18N_CERT_KS_3));
             }
          }
	}
}
