/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.iexplorer;

import java.security.Provider;

/**
 * <p>Proveedor que implementa el algoritmo de firma SHA1withRSA para Internet Explorer
 * 5.5 o superior en sistemas operativos Windows 98 2ª Edition o superiores.</p>
 *
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */

public final class MITyCMSProvider extends Provider {
	
	/** Nombre del proveedor específico para MS.*/
	public static final String PROVIDER_MS = "MITyCMSProvider";
	/** Descripción del proveedor. */
	private static final String PROVIDER_MS_DESCRIPTION = "MITyCMSProvider v1.0, implementación de SHA1withRSA basado en KeyStore de Microsoft y OpenOCES - OpenSign";
	/** Nombre del algoritmo de firma implementado en este proveedor. */
	private static final String SIGNATURE_SHA1_WITH_RSA = "Signature.SHA1withRSA";
	/** Nombre de la clase que gestiona las labores de firma. */
	private static final String ENGINE_CLASS = IESignEngine.class.getName(); //"es.mityc.javasign.pkstore.iexplorer.IESignEngine";

    /**
     * <p>Crea una nueva instancia de ProveedorCriptograficoMS.</p>
     */
    public MITyCMSProvider() {
        super(PROVIDER_MS, 1.0, PROVIDER_MS_DESCRIPTION);
        super.put(SIGNATURE_SHA1_WITH_RSA, ENGINE_CLASS);
    }
}
