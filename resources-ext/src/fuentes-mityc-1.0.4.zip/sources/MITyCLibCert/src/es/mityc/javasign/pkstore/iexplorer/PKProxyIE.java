/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.iexplorer;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * <p>Actúa como proxy de clave privada para el acceso a claves privadas de un almacén de IExplorer mediante la interfaz nativa DLLFirmaVC.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class PKProxyIE implements PrivateKey {
	
	/** Certificado asociado a la clave privada. */
	private X509Certificate certificatePK;
	
	/**
	 * <p>Crea el proxy relacionado con un certificado del almacén.</p>
	 * 
	 * @param certificate certificado asociado con la clave privada
	 */
	public PKProxyIE(final X509Certificate certificate) {
		this.certificatePK = certificate;
	}
	
	/**
	 * <p>Devuelve el certificado relacionado con la clave privada relacionada con este proxy.</p>
	 * @return Certificado asociado con la clave privada
	 */
	public X509Certificate getCertificate() {
		return certificatePK;
	}

	/**
	 * <p>Sin uso.</p>
	 * @return sin uso
	 * @see java.security.Key#getAlgorithm()
	 */
	public String getAlgorithm() {
		return null;
	}

	/**
	 * <p>Sin uso.</p>
	 * @return sin uso
	 * @see java.security.Key#getEncoded()
	 */
	public byte[] getEncoded() {
		return null;
	}

	/**
	 * <p>Sin uso.</p>
	 * @return sin uso
	 * @see java.security.Key#getFormat()
	 */
	public String getFormat() {
		return null;
	}

}
