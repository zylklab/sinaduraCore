 /**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.mozilla;

/**
 * <p>Enumerado de los modos de funcionamiento del login de tokens en Mozilla.</p>
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public enum MozillaTokenLoginModeEnum {
	/** Sólo hay que logarse en el token la primera vez que se accede a el. */
    ONE_TIME (0),
    /** Hay que logarse en el token cada # tiempo. */
    TIMEOUT (1),
    /** hay que logarse en el token cada vez que se intenta acceder a el. */
    EVERY_TIME (2);
    
    /** Valor numérico equivalente al modo del enumerado .*/
    private int emode = 0;
    
    /**
     * <p>Construye un modo del enumerado relacionándolo con un valor numérico.</p>
     * @param mode equivalente numérico al modo según Mozilla
     */
    private MozillaTokenLoginModeEnum(int mode) {
    	emode = mode;
    }
    
    /**
     * <p>Indica cuál es el modo de funcionamiento por defecto.</p>
     * <p>El modo por defecto es: logarse sólo la primera vez que se utiliza.</p>
     * @return modo de funcionamiento por defecto
     */
    public static MozillaTokenLoginModeEnum getDefault() {
    	return ONE_TIME;
    }
    
    /**
     * <p>Devuelve el enumerado de funcionamiento en función de un valor numérico.</p>
     * <p>La correspondencia es:
     * 	<dd>0</dd><dt>ONE_TIME</dt>
     * 	<dd>1</dd><dt>TIMEOUT</dt>
     * 	<dd>2</dd><dt>EVERY_TIME</dt>
     * </p>
     * 
     * @param mode valor numérico de mozilla
     * @return enumerado relacionado
     */
    public static MozillaTokenLoginModeEnum getLoginMode(final int mode) {
    	MozillaTokenLoginModeEnum emod;
    	switch (mode) {
	    	case 0:
	    		emod = ONE_TIME;
	    		break;
	    	case 1:
	    		emod = TIMEOUT;
	    		break;
	    	case 2:
	    		emod = EVERY_TIME;
	    		break;
	    	default:
	    		emod = ONE_TIME;
    	}
    	return emod;
    }

    /**
     * <p>Devuelve el valor numérico según Mozilla equivalente al enumerado.</p>
     * @return valor numérico del modo
     */
    public int getInteger() {
    	return emode;
    }
}
