/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */

package es.mityc.javasign.pkstore.pkcs11;

import java.security.Provider;

/**
 * <p>Interfaz que ha de implementar un informador de un provider que permite acceso a <u>un dispositivo</u> PKCS#11.</p>
 * <p>A diferencia de {@link IModuleData} este interfaz representa a un único dispositivo de un tipo que podría estar conectado
 * en un momento dado.</p> * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public interface IProviderData {
	
	/**
	 * <p>Devuelve el provider que permite el acceso al slot.</p>
	 * @return Provider
	 */
	Provider getProvider();
	
	/**
	 * <p>Devuelve el nombre del keystore que administra este provider para acceder al dispositivo PKCS#11.</p>
	 * <p>Este nombre se puede utilizar después en la clase {@link java.security.KeyStore} para acceder al almacén de certificados
	 * disponibles en el módulo PKCS#11 accedido por este provider.</p>
	 * @return  Nombre del tipo de KeyStore
	 */
	String getKeyStoreTypeName();

}
