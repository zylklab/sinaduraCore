/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA o consulte
 * <http://www.gnu.org/licenses/>.
 *
 * Copyright 2008 Ministerio de Industria, Turismo y Comercio
 * 
 */

package es.mityc.javasign.pkstore.mozilla;

/**
 * <p>Interfaz que han de implementar los dialogs de petición de PIN para permitir la configuración de los mensajes mostrados.</p>
 *
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 0.9 beta
 */

public interface IPINDialogConfigurable {
	
	/** Tipos de modos de funcionamiento de los mensajes de la ventana.*/
	public enum MESSAGES_MODE { AUTO, AUTO_TOKEN, EXPLICIT };
	
	/**
	 * <p>Establece el titulo de la ventana de petición de PIN.</p>
	 * @param title Título de la ventana
	 */
	void setTitle(String title);
	
	/**
	 * <p>Establece el mensaje de qué tipo de dato de identificación espera.</p>
	 * @param message Mensaje de tipo de contraseña esperada
	 */
	void setPINMessage(String message);
	
	/**
	 * Indica el modo en el que se deben obtener los mensajes de la ventana. Por defecto (o por ausencia de valor) actúa como AUTO.
	 * @param mode	<ul><li>AUTO indica que el dialog buscará sus propios títulos</li> 
	 * 				<li>AUTO_TOKEN indica que utilizará los títulos que le proporcione el token</li>
	 * 				<li>EXPLICIT indica que utilizará los títulos que se le provea a través de los métodos de este interfaz</li></ul>
	 */
	void setMessagesMode(MESSAGES_MODE mode);

}
