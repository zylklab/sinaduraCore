/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.macosx;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertPath;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

import es.mityc.javasign.i18n.I18nFactory;
import es.mityc.javasign.i18n.II18nManager;
import es.mityc.javasign.pkstore.CertStoreException;
import es.mityc.javasign.pkstore.ConstantsCert;
import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.IPassStoreKS;
import es.mityc.javasign.pkstore.NullPassStorePK;
import es.mityc.javasign.pkstore.keystore.KSStore;

/**
 * <p>Wrapper para permitir utilizar el almacén de claves de Apple en los componentes de firma.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class MacOSXStore implements IPKStoreManager {
	/** Internacionalizador. */
	private static final II18nManager I18N = I18nFactory.getI18nManager(ConstantsCert.LIB_NAME);
	
	/** Nombre del provider del almacén de Mac OS X. */
	private static final String APPLE_KEYSTORE = "Apple";
	/** Cadena vacía. */
	private static final char[] APPLE_EMPTY_STRING = "-".toCharArray();
	
	/** Store del tipo KeyStore que realmente realiza los accesos al almacén de MacOS X. */
	private IPKStoreManager pkStore;
	
	/**
	 * <p>Constructor.</p>
	 * @throws CertStoreException Lanzada si no se puede acceder al almacén de claves de Apple
	 */
	public MacOSXStore() throws CertStoreException {
		this(new NullPassStorePK());
	}

	/**
	 * <p>Constructor.</p>
	 * 
	 * @param passwordHandler Manejador que servirá para recuperar las claves del KeyStore
	 * @throws CertStoreException Lanzada si no se puede acceder al almacén de claves de Apple
	 */
	public MacOSXStore(IPassStoreKS passwordHandler) throws CertStoreException {
		try {
			KeyStore appleKs = KeyStore.getInstance("KeychainStore", APPLE_KEYSTORE);
			appleKs.load(null, null);
			pkStore = new KSStore(appleKs, passwordHandler, APPLE_EMPTY_STRING);
		} catch (NoSuchProviderException ex) {
			throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MACOSX_1, ex.getMessage()), ex);
		} catch (KeyStoreException ex) {
			throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MACOSX_1, ex.getMessage()), ex);
		} catch (NoSuchAlgorithmException ex) {
			throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MACOSX_1, ex.getMessage()), ex);
		} catch (CertificateException ex) {
			throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MACOSX_1, ex.getMessage()), ex);
		} catch (IOException ex) {
			throw new CertStoreException(I18N.getLocalMessage(ConstantsCert.I18N_CERT_MACOSX_1, ex.getMessage()), ex);
		}
	}
	
	/**
	 * <p>Devuelve el Provider que permite trabajar con el KeyStore configurado.</p>
     * @param cert Certificado para el que se necesita acceso al provider
	 * @return Provider asociado al KeyStore
	 */
	public Provider getProvider(final X509Certificate cert) {
		return Security.getProvider("SunRsaSign");
	}
	
	/**
	 * <p>Devuelve la cadena de certificación de un certificado.</p>
	 * @param certificate certificado del que construir la cadena
	 * @return Cadena de certificación
	 * @throws CertStoreException Lanzado si hay algún problema en la construcción de la cadena
	 * @see es.mityc.javasign.pkstore.keystore.KSStore#getCertPath(X509Certificate)
	 */
	public CertPath getCertPath(final X509Certificate certificate) throws CertStoreException {
		return (pkStore != null) ? pkStore.getCertPath(certificate) : null;
	}
	
	/**
	 * <p>Devuelveun proxy a la clave privada asociada al certificado indicado.</p>
	 * @param certificate certificado del que se consulta la clave privada
	 * @return clave privada asociada al certificado
	 * @throws CertStoreException Lanzado si hay algún problema al intentar recuperar la clave privada o no existe
	 * @see es.mityc.javasign.pkstore.keystore.KSStore#getPrivateKey(X509Certificate)
	 */
	public PrivateKey getPrivateKey(final X509Certificate certificate) throws CertStoreException {
		return (pkStore != null) ? pkStore.getPrivateKey(certificate) : null;
	}
	
	/**
	 * <p>Recupera los certificados que pueden firmar (disponen de clave privada) de este almacén.</p>
	 * @return Listado de certificados que pueden firmar
	 * @throws CertStoreException Lanzado si hay algún problema en la recuperación de certificados
	 * @see es.mityc.javasign.pkstore.keystore.KSStore#getSignCertificates()
	 */
	public List<X509Certificate> getSignCertificates() throws CertStoreException {
		return (pkStore != null) ? pkStore.getSignCertificates() : null;
	}
	
	/**
	 * <p>Recupera los certificados de confianza de este almacén.</p>
	 * @return Listado de certificados de confianza
	 * @throws CertStoreException Lanzado si hay algún problema en la recuperación de certificados
	 * @see es.mityc.javasign.pkstore.keystore.KSStore#getTrustCertificates()
	 */
	public List<X509Certificate> getTrustCertificates() throws CertStoreException {
		return (pkStore != null) ? pkStore.getTrustCertificates() : null;
	}

}
