/*
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.examples;

import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.mozilla.MozillaStore;

/**
 * <p>
 * Ejemplo que lista el almacén de certificados de Firefox
 * </p>
 * 
 * @author Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class FirefoxCertificateStoreListing extends
        GenericCertificateStoreListing {

    /**
     * Directorio donde se encuentra el perfil de Mozilla del que se desean
     * listar los certificados. Dependiendo del sistema operativo, la ruta será
     * de una forma u otra:
     * <ul>
     * <li>Windows:
     * <code>C:/Documents and Settings/<b>usuario</b>/Datos de programa/Mozilla/Firefox/Profiles/<b>perfil</b></code>
     * </li>
     * <li>Linux: <code>~/.mozilla/firefox/<b>perfil</b></code></li>
     * </ul>
     */
    private static final String MOZILLA_PROFILE_DIRECTORY = "";

    /**
     * <p>
     * Punto de entrada al programa
     * </p>
     * 
     * @param args
     *            Argumentos del programa
     */
    public static void main(String[] args) {
        FirefoxCertificateStoreListing certificateStoreListing = new FirefoxCertificateStoreListing();
        certificateStoreListing.execute();
    }

    @Override
    protected IPKStoreManager getPKStoreManager() {
        return new MozillaStore(MOZILLA_PROFILE_DIRECTORY);
    }

}
