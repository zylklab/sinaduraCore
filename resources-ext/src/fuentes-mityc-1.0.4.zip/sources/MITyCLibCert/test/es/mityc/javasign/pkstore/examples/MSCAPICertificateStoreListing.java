/*
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.examples;

import es.mityc.javasign.pkstore.CertStoreException;
import es.mityc.javasign.pkstore.DefaultPassStoreKS;
import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.mscapi.MSCAPIStore;

/**
 * <p>
 * Ejemplo que lista el almacén de certificados de Windows a través del proveedor
 * de seguridad SunMSCAPI-MITyC, siempre y cuando el JAR correspondiente a dicho 
 * proveedor esté accesible en el classpath, o mediante el proveedor SunMSCAPI
 * en caso contrario. En el caso de usar el proveedor SunMSCAPI será necesario 
 * hacer uso de Java 1.6+. En el caso de usar el proveedor SunMSCAPI-MITyC, será
 * suficiente con utilizar Java 1.5+
 * </p>
 * 
 * @author Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class MSCAPICertificateStoreListing extends
        GenericCertificateStoreListing {

    /**
     * <p>
     * Punto de entrada al programa
     * </p>
     * 
     * @param args
     *            Argumentos del programa
     */
    public static void main(String[] args) {
        MSCAPICertificateStoreListing certificateStoreListing = new MSCAPICertificateStoreListing();
        certificateStoreListing.execute();
    }

    @Override
    protected IPKStoreManager getPKStoreManager() {
        try {
            return new MSCAPIStore(new DefaultPassStoreKS());
        } catch (CertStoreException e) {
            System.err.println("Error al crear el almacén");
            e.printStackTrace();
            System.exit(-1);
            return null;
        }
    }

}
