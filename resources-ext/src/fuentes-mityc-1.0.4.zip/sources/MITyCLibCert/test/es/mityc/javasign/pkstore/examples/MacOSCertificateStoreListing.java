/*
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.pkstore.examples;

import es.mityc.javasign.pkstore.CertStoreException;
import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.macosx.MacOSXStore;

/**
 * <p>
 * Ejemplo que lista el almacén de certificados de Mac OS a través de 
 * las clases contenidas en MacOsStore.
 * </p>
 * 
 * @author Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class MacOSCertificateStoreListing extends GenericCertificateStoreListing {
	
    /**
     * <p>Punto de entrada al programa.</p>
     * @param args El programa no admite argumentos
     */
    public static void main(String[] args) {
    	MacOSCertificateStoreListing certificateStoreListing = new MacOSCertificateStoreListing();
        certificateStoreListing.execute();
    }

    @Override
    protected IPKStoreManager getPKStoreManager() {
    	// se instancia y se devuelve el almacén
        try {
			return new MacOSXStore();
		} catch (CertStoreException e) {
			e.printStackTrace();
			return null;
		}
    }
}
