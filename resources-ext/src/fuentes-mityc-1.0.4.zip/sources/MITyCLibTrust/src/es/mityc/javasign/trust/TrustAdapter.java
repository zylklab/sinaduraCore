/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.trust;

import java.security.cert.CertPath;
import java.security.cert.X509CRL;

import org.bouncycastle.ocsp.OCSPResp;
import org.bouncycastle.tsp.TimeStampToken;

/**
 * <p>Clase base que redirige las peticiones de un manager que sigue {@link TrustAbstract} a uno de la factoría extendidad que implemente los
 * interfaces propios.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public abstract class TrustAdapter extends TrustAbstract implements ITrustCRLEmisor,
		ITrustOCSPProducer, ITrustSignCerts, ITrustTSProducer {

	/**
	 * <p>Discrimina en función del tipo de objeto qué método hay que lanzar de la clase que lo extienda.</p>
	 * <p>Discrimina entre los objetos: cadena de certificados, sello de tiempo, CRL y respuesta OCSP.</p>
	 * @param data objeto del que hay que comprobar su confianza
	 * @throws TrustException Lanzada cuando no se confía en el elemento. Lanza una de tipo UnknownTrustException cuando no se reconoce el tipo de objeto
	 * @see es.mityc.javasign.trust.TrustAbstract#isTrusted(java.lang.Object)
	 */
	@Override
	public void isTrusted(final Object data) throws TrustException {
		if (data instanceof CertPath) {
			isTrusted((CertPath) data);
		} else if (data instanceof TimeStampToken) {
			isTrusted((TimeStampToken) data);
		} else if (data instanceof X509CRL) {
			isTrusted((X509CRL) data);
		} else if (data instanceof OCSPResp) {
			isTrusted((OCSPResp) data);
		} else {
			throw new UnknownTrustException();
		}
	}

}
