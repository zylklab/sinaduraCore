/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.trust;

import java.security.cert.CertPath;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;

import org.bouncycastle.ocsp.OCSPResp;
import org.bouncycastle.tsp.TimeStampToken;

/**
 * <p>Manager de absoluta confianza.</p>
 * <p>Se da por válidos todos los elementos. Clase de test.</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public final class AllTrusted extends TrustAdapter {
	
	/** Instancia única del manager de confianza. */
	private static AllTrusted instance = new AllTrusted();

	/**
	 * <p>Da como válida la CRL.</p>
	 * @param crl CRL
	 * @throws TrustException Nunca se lanza
	 * @see es.mityc.javasign.trust.ITrustCRLEmisor#isTrusted(java.security.cert.X509CRL)
	 */
	public void isTrusted(final X509CRL crl) throws TrustException {
	}

	/**
	 * <p>Da como válida la respuesta OCSP.</p>
	 * @param ocsp Respuesta OCSP
	 * @throws TrustException Nunca se lanza
	 * @see es.mityc.javasign.trust.ITrustOCSPProducer#isTrusted(org.bouncycastle.ocsp.OCSPResp)
	 */
	public void isTrusted(final OCSPResp ocsp) throws TrustException {
	}

	/**
	 * <p>Da como válida la cadena de certificación.</p>
	 * @param certs Cadena de certificados
	 * @throws TrustException Nunca se lanza
	 * @see es.mityc.javasign.trust.ITrustSignCerts#isTrusted(java.security.cert.CertPath)
	 */
	public void isTrusted(final CertPath certs) throws TrustException {
	}

	/**
	 * <p>Da como válido el sello de tiempo.</p>
	 * @param tst Sello de tiempo
	 * @throws TrustException Nunca se lanza
	 * @see es.mityc.javasign.trust.ITrustTSProducer#isTrusted(org.bouncycastle.tsp.TimeStampToken)
	 */
	public void isTrusted(final TimeStampToken tst) throws TrustException {
	}

	/**
	 * <p>Devuelve una instancia única del manager.</p>
	 * <p>Este clase se puede utilizar sin protección de sincronismo.</p>
	 * @return Instancia única del manager
	 */
	public static TrustAbstract getInstance() {
		return instance;
	}
	
	@Override
	public CertPath getCertPath(X509Certificate cert) throws UnknownTrustException {
		throw new UnknownTrustException("Not implemented");
	}
}
