/**
 * LICENCIA LGPL:
 * 
 * Esta librería es Software Libre; Usted puede redistribuirlo y/o modificarlo
 * bajo los términos de la GNU Lesser General Public License (LGPL)
 * tal y como ha sido publicada por la Free Software Foundation; o
 * bien la versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior.
 * 
 * Esta librería se distribuye con la esperanza de que sea útil, pero SIN NINGUNA
 * GARANTÍA; tampoco las implícitas garantías de MERCANTILIDAD o ADECUACIÓN A UN
 * PROPÓSITO PARTICULAR. Consulte la GNU Lesser General Public License (LGPL) para más
 * detalles
 * 
 * Usted debe recibir una copia de la GNU Lesser General Public License (LGPL)
 * junto con esta librería; si no es así, escriba a la Free Software Foundation Inc.
 * 51 Franklin Street, 5º Piso, Boston, MA 02110-1301, USA.
 * 
 */
package es.mityc.javasign.trust;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.Properties;

import es.mityc.javasign.ConstantsAPI;

/**
 * <p>Gestiona las entidades de confianza que admite MITyC.</p>
 * <p>Esta clase se basa en ficheros de configuración para parametrizar los certificados admitidos (en /trust/mitycsimple.properties).</p>
 * 
 * @author  Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class MyPropsTruster extends PropsTruster implements ITrustServices {

	/** Nombre del fichero de configuración interno. */
	private static final String CONF_FILE = "trust/myTruster.properties";
	
	/** Nombre del fichero de propiedades del repositorio externo. */
	private static final String EXT_CONF_FILE = "truster.properties";
	
	/** Ruta por defecto al repositorio externo. */
	private static final String USER_PATH_CONF = "myTrusterPath.properties";
	private static final String PATH_KEY = "es.mityc.myTruster.path";

	/**
	 * <p>Constructor.</p>
	 */
	public MyPropsTruster(String externalConfPath) {
		super(CONF_FILE, externalConfPath);
	}
	
	/**
	 * <p>Devuelve una instancia única del gestionador de confianza propio.</p>
	 * @param ruta al fichero de configuración de confianza externo  
	 * @return Instancia de este gestionador de confianza
	 */
	public static synchronized TrustAdapter getInstance(String externalConfPath) {
		if (instance == null) {
			instance = new MyPropsTruster(externalConfPath);
		}
		return instance;
	}
	
	/**
	 * <p>Vuelve a cargar los properties de gestion de confianza.</p>
	 * @param Ruta al fichero de configuración de confianza externo  
	 */
	private static synchronized void reloadInstance(String externalConfPath) {
		((PropsTruster) instance).loadConf(CONF_FILE, externalConfPath);
	}
	
	/**
	 * <p>Permite incluir un certificado en el repositorio por defecto.<p>
	 * @param cert Certificado a incluir.
	 * @param type Tipo de certificado.
	 * @see es.mityc.javasign.trust.PropsTruster.TrusterType
	 */
	public void addCA(X509Certificate cert, TrusterType type) throws TrustException {
		Properties props = new Properties();
		try {
			props.load(this.getClass().getResourceAsStream(USER_PATH_CONF));
		} catch (IOException e) {}
		
		if (props != null && props.contains(PATH_KEY)) {
			addCA(cert, type, System.getProperty(ConstantsAPI.SYSTEM_PROPERTY_USER_HOME) + props.getProperty(PATH_KEY));
		} else {
			throw new TrustException();
		}
	}

	/**
	 * <p>Permite incluir un certificado en el repositorio indicado.<p>
	 * @param cert Certificado a incluir.
	 * @param type Tipo de certificado.
	 * @param path Ruta física al repositorio
	 * @see es.mityc.javasign.trust.PropsTruster.TrusterType
	 */
	public void addCA(X509Certificate cert, TrusterType type, String path) throws TrustException {
		// Se obtiene el CN-O del certificado
		String[] dn = cert.getSubjectX500Principal().getName("CANONICAL").split(",");
		String subjectName = dn[2].substring(dn[2].lastIndexOf('=') + 1);
		subjectName = subjectName.replace(" ", "");
		if (subjectName.length() > 16) {
			subjectName = subjectName.substring(0, 16);
		}
		
		// Se guarda el certificado en una ubicación específica, a partir del Path indicado
		String pathToCert = path + File.separator + "CAs";
		// Si el directorio destino no existe, se crea
		File desFile = new File(pathToCert);
		if (!desFile.exists()) {
			desFile.mkdir();
		}
		
		// Se construye el destino de la firma
		pathToCert = path + File.separator + "CAs" + File.separator + subjectName + ".cer";
		
		// Se hace efectiva la escritura del certificado
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(pathToCert);
			fos.write(cert.getEncoded());
		} catch (IOException e) {
			throw new TrustException(e);
		} catch (CertificateEncodingException e) {
			throw new TrustException(e);
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {}
			}
		}

		// Se carga el fichero de propiedades externo
		String extPropsPath = path + File.separator + EXT_CONF_FILE;
		
		// Se comprueba que exista el fichero externo de propiedades, y si no existe, se crea
		File extPropsFile = new File(extPropsPath);
		if (!extPropsFile.exists()) {
			try {
				if (!extPropsFile.createNewFile())
					return;
			} catch (IOException e) {
				throw new TrustException(e);
			}
		}

		// Se modifica el fichero de propiedades para incluir la nueva referencia
		try {
			Properties props = new Properties();
			FileInputStream fis = new FileInputStream(extPropsFile);
			props.load(fis);
			fis.close();
			
			// Se calcula la Key correspondiente
			String key = type.toString() + '.' + subjectName;
			for (int i = 2; props.contains(key); ++i) {
				key = type.toString() + '.' + subjectName + i;
			}
			
			// Se hace efectiva la inclusión
			props.setProperty(key, pathToCert);
			
			// Se guardan los cambios
			fos = new FileOutputStream(extPropsFile);
			props.store(fos, null);
			reloadInstance(extPropsPath);
		} catch (IOException e) {
			throw new TrustException(e);
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {}
			}
		}
	}
}
