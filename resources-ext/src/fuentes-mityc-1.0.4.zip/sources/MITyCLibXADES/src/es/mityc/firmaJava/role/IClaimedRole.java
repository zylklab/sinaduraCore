package es.mityc.firmaJava.role;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

public interface IClaimedRole {
	
	public Node createClaimedRoleContent(Document doc);

}
